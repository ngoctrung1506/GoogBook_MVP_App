package giaodien.admin.doan_googbook.screen.home.upload;

import giaodien.admin.doan_googbook.model.Doc;
import giaodien.admin.doan_googbook.model.SimpleResult;
import giaodien.admin.doan_googbook.network.NetWorkController;
import giaodien.admin.mylibrary.base.viper.Interactor;
import retrofit2.Callback;

/**
 * The Upload interactor
 */
class UploadInteractor extends Interactor<UploadContract.Presenter>
    implements UploadContract.Interactor {

  UploadInteractor(UploadContract.Presenter presenter) {
    super(presenter);
  }

  @Override
  public void uploadDoc(int userId, Doc doc, Callback<SimpleResult> simpleResultCallback) {
    NetWorkController.uploadDoc(userId, doc, simpleResultCallback);
  }
}
