package giaodien.admin.doan_googbook.screen.home.upload;

import android.util.Log;

import giaodien.admin.doan_googbook.model.Doc;
import giaodien.admin.doan_googbook.model.Post;
import giaodien.admin.doan_googbook.model.SimpleResult;
import giaodien.admin.mylibrary.base.viper.Presenter;
import giaodien.admin.mylibrary.base.viper.interfaces.ContainerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * The Upload Presenter
 */
public class UploadPresenter extends Presenter<UploadContract.View, UploadContract.Interactor>
    implements UploadContract.Presenter {

  private Post mPost;
  public UploadPresenter(ContainerView containerView) {
    super(containerView);
  }

  @Override
  public UploadContract.View onCreateView() {
    return UploadFragment.getInstance();
  }

  @Override
  public void start() {
    // Start getting data here
    if(mPost != null) mView.setUpView(mPost);
  }

  @Override
  public UploadContract.Interactor onCreateInteractor() {
    return new UploadInteractor(this);
  }

  public UploadPresenter getPostInfomation(Post post) {
    this.mPost = post;
    return this;
  }

  @Override
  public void uploadDoc(int userId, Doc doc) {

    mInteractor.uploadDoc(userId, doc, new Callback<SimpleResult>() {
      @Override
      public void onResponse(Call<SimpleResult> call, Response<SimpleResult> response) {

        if(response.isSuccessful() && response.body() != null){
          Log.d("error", "No error");
        }
        else Log.d("error", response.message());

      }

      @Override
      public void onFailure(Call<SimpleResult> call, Throwable t) {
        Log.d("error", t.getMessage());
      }
    });
  }
}
