package giaodien.admin.doan_googbook.constants;

/**
 * Created by Admin on 11/10/2017.
 */

public class Constants {

  public static String BASE_MOCK_URL = "http://demo7904624.mockable.io/";
  public static String BASE_URL = "http://192.168.1.88:8080/RESTfulCRUD/rest/";
  public static String USER_ACCOUNT = "user_account";
  public static String USER_PASSWORD = "user_password";
  public static String USER_ID = "user_id";
  public static String USER_AVATAR = "user_avatar";
  public static String USER_BACKGROUND = "user_background";
  public static String SAVED = "saved";
  public static int TRUE = 0;
  public static int FALSE = 1;

}
