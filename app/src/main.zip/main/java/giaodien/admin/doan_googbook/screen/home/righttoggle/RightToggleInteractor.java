package giaodien.admin.doan_googbook.screen.home.righttoggle;

import giaodien.admin.mylibrary.base.viper.Interactor;

/**
 * The Personal interactor
 */
class RightToggleInteractor extends Interactor<RightToggleContract.Presenter>
    implements RightToggleContract.Interactor {

  RightToggleInteractor(RightToggleContract.Presenter presenter) {
    super(presenter);
  }
}
