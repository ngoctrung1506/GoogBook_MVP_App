package giaodien.admin.doan_googbook.screen.home;

import giaodien.admin.doan_googbook.base.GoogBaseActivity;
import giaodien.admin.doan_googbook.screen.home.login.LogInPresenter;
import giaodien.admin.mylibrary.base.viper.ViewFragment;

public class HomeActivity extends GoogBaseActivity {

  @Override
  public ViewFragment onCreateFirstFragment() {
    return (ViewFragment) new LogInPresenter(this).getFragment();
  }


}
