package giaodien.admin.doan_googbook.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Admin on 09/10/2017.
 */

public class SimpleResult implements Serializable {

  @SerializedName("errorCode")
  private int errrorCode;

  @SerializedName("msg")
  private String msg;

  @SerializedName("userId")
  private int userId;

  public int getErrrorCode() {
    return errrorCode;
  }

  public String getMsg() {
    return msg;
  }

  public int getUserId() {
    return userId;
  }
}
